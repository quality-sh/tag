import { test, expect } from '@playwright/test';
test.describe('checkout', () => {
  test('adds an item to the cart', async ({ page }) => {
    await page.setContent('<button id="add">Add</button><span id="count">0</span><script>document.getElementById("add").onclick=()=>{document.getElementById("count").textContent="1"}</script>');
    await page.click('#add');
    await expect(page.locator('#count')).toHaveText('1');
  });
  test('shows the total', async ({ page }) => {
    await page.setContent('<p id="total">$42.00</p>');
    await expect(page.locator('#total')).toHaveText('$42.00');
  });
  test('applies a discount code', async ({ page }) => {
    await page.setContent('<p id="total">$42.00</p>');
    await expect(page.locator('#total')).toHaveText('$42.00');
  });
  test.skip('ships internationally', async () => {});
});
