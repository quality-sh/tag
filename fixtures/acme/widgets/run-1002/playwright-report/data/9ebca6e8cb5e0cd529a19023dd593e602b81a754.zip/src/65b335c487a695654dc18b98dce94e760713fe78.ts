import { test, expect } from '@playwright/test';
test.describe('auth', () => {
  test('logs in with a valid password', async ({ page }) => {
    await page.setContent('<h1>Welcome back</h1>');
    await expect(page.locator('h1')).toHaveText('Welcome back');
  });
  test('rejects a bad password', async ({ page }) => {
    await page.setContent('<p role="alert">Invalid credentials</p>');
    await expect(page.getByRole('alert')).toBeVisible();
  });
});
